﻿namespace SKimAssignment2
{
    partial class SKimGamePlaying
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnumbmove = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnRIGHT = new System.Windows.Forms.Button();
            this.BtnUP = new System.Windows.Forms.Button();
            this.BtnLEFT = new System.Windows.Forms.Button();
            this.BtnDOWN = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtnumbofpush = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LoadFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtnumbmove
            // 
            this.txtnumbmove.Location = new System.Drawing.Point(1127, 97);
            this.txtnumbmove.Name = "txtnumbmove";
            this.txtnumbmove.Size = new System.Drawing.Size(186, 20);
            this.txtnumbmove.TabIndex = 16;
            this.txtnumbmove.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1124, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Number of Moves";
            // 
            // BtnRIGHT
            // 
            this.BtnRIGHT.Location = new System.Drawing.Point(1289, 598);
            this.BtnRIGHT.Name = "BtnRIGHT";
            this.BtnRIGHT.Size = new System.Drawing.Size(75, 68);
            this.BtnRIGHT.TabIndex = 13;
            this.BtnRIGHT.Text = "RIGHT";
            this.BtnRIGHT.UseVisualStyleBackColor = true;
            this.BtnRIGHT.Click += new System.EventHandler(this.BtnRIGHT_Click);
            // 
            // BtnUP
            // 
            this.BtnUP.Location = new System.Drawing.Point(1208, 524);
            this.BtnUP.Name = "BtnUP";
            this.BtnUP.Size = new System.Drawing.Size(75, 68);
            this.BtnUP.TabIndex = 12;
            this.BtnUP.Text = "UP";
            this.BtnUP.UseVisualStyleBackColor = true;
            this.BtnUP.Click += new System.EventHandler(this.BtnUP_Click);
            // 
            // BtnLEFT
            // 
            this.BtnLEFT.Location = new System.Drawing.Point(1127, 598);
            this.BtnLEFT.Name = "BtnLEFT";
            this.BtnLEFT.Size = new System.Drawing.Size(75, 68);
            this.BtnLEFT.TabIndex = 11;
            this.BtnLEFT.Text = "LEFT";
            this.BtnLEFT.UseVisualStyleBackColor = true;
            this.BtnLEFT.Click += new System.EventHandler(this.BtnLEFT_Click);
            // 
            // BtnDOWN
            // 
            this.BtnDOWN.Location = new System.Drawing.Point(1208, 598);
            this.BtnDOWN.Name = "BtnDOWN";
            this.BtnDOWN.Size = new System.Drawing.Size(75, 68);
            this.BtnDOWN.TabIndex = 10;
            this.BtnDOWN.Text = "DOWN";
            this.BtnDOWN.UseVisualStyleBackColor = true;
            this.BtnDOWN.Click += new System.EventHandler(this.BtnDOWN_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1396, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadGameToolStripMenuItem
            // 
            this.loadGameToolStripMenuItem.Name = "loadGameToolStripMenuItem";
            this.loadGameToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loadGameToolStripMenuItem.Text = "Load Game";
            this.loadGameToolStripMenuItem.Click += new System.EventHandler(this.LoadGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // txtnumbofpush
            // 
            this.txtnumbofpush.Location = new System.Drawing.Point(1127, 161);
            this.txtnumbofpush.Name = "txtnumbofpush";
            this.txtnumbofpush.Size = new System.Drawing.Size(186, 20);
            this.txtnumbofpush.TabIndex = 19;
            this.txtnumbofpush.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1124, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Number of Push";
            // 
            // LoadFileDialog1
            // 
            this.LoadFileDialog1.FileName = "LoadFileDialog1";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // SKimGamePlaying
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1396, 685);
            this.Controls.Add(this.txtnumbofpush);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtnumbmove);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnRIGHT);
            this.Controls.Add(this.BtnUP);
            this.Controls.Add(this.BtnLEFT);
            this.Controls.Add(this.BtnDOWN);
            this.Controls.Add(this.menuStrip1);
            this.Name = "SKimGamePlaying";
            this.Text = "SKimGamePlaying";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtnumbmove;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnRIGHT;
        private System.Windows.Forms.Button BtnUP;
        private System.Windows.Forms.Button BtnLEFT;
        private System.Windows.Forms.Button BtnDOWN;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.TextBox txtnumbofpush;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.OpenFileDialog LoadFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}