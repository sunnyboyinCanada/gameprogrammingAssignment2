﻿namespace SKimAssignment2
{
    partial class SKimGameControlPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnGamePlaying = new System.Windows.Forms.Button();
            this.BtnGameDesign = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.Location = new System.Drawing.Point(99, 86);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(163, 68);
            this.BtnExit.TabIndex = 5;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnGamePlaying
            // 
            this.BtnGamePlaying.Location = new System.Drawing.Point(181, 12);
            this.BtnGamePlaying.Name = "BtnGamePlaying";
            this.BtnGamePlaying.Size = new System.Drawing.Size(163, 68);
            this.BtnGamePlaying.TabIndex = 4;
            this.BtnGamePlaying.Text = "Play";
            this.BtnGamePlaying.UseVisualStyleBackColor = true;
            this.BtnGamePlaying.Click += new System.EventHandler(this.BtnGamePlaying_Click);
            // 
            // BtnGameDesign
            // 
            this.BtnGameDesign.Location = new System.Drawing.Point(12, 12);
            this.BtnGameDesign.Name = "BtnGameDesign";
            this.BtnGameDesign.Size = new System.Drawing.Size(163, 68);
            this.BtnGameDesign.TabIndex = 3;
            this.BtnGameDesign.Text = "Design";
            this.BtnGameDesign.UseVisualStyleBackColor = true;
            this.BtnGameDesign.Click += new System.EventHandler(this.BtnGameDesign_Click);
            // 
            // SKimGameControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 163);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnGamePlaying);
            this.Controls.Add(this.BtnGameDesign);
            this.Name = "SKimGameControlPanel";
            this.Text = "SKimGame Control Panel";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnGamePlaying;
        private System.Windows.Forms.Button BtnGameDesign;
    }
}

