﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SKimAssignment2
{
    public partial class Tile : PictureBox
    {

        public int row;
        public int col;
        public int toolType;

        private const int LEFT = 100;
        private const int TOP = 100;
        private const int WIDTH = 50;
        private const int HEIGHT = 50;
        public Tile(int row, int col, int toolType)
        {
            this.row = row;
            this.col = col;
            this.toolType = toolType;
            this.Width = WIDTH;
            this.Height = HEIGHT;
            this.BorderStyle = BorderStyle.FixedSingle;
            this.SizeMode = PictureBoxSizeMode.Zoom;
            updateTile();
            
        }

       
        public void updateTile()
        {
            this.Left = LEFT + WIDTH * col;
            this.Top = TOP + HEIGHT * row;

            
        }
    }
}
