﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SKimAssignment2
{
    public partial class SKimGameDesign : Form
    {

        private const int INIT_TOP = 125;
        private const int INIT_LEFT = 160;
        private const int WIDTH = 50;
        private const int HEIGHT = 50;
        private const int VGAP = 10;
        private const int HGAP = 10;
        private string pictureforthebutton;

        enum MyTool
        {

            None,
            Wall,
            YellowBox,
            YellowDoor,
            Hero

        }

        MyTool currentTool;

        public SKimGameDesign()
        {
            InitializeComponent();
        }

        private void MenuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
