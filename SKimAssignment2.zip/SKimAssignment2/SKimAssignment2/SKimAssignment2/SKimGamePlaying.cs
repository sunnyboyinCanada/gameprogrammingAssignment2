﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SKimAssignment2
{
    public partial class SKimGamePlaying : Form
    {
        enum MyTool
        {

            None,
            Wall,
            YellowBox,
            YellowDoor,
            Hero

        }

        MyTool currentTool;

        public const int HERO = 1;
        public const int WALL = 2;
        public const int BOX = 3;
        public const int DOOR = 4;
        public const int NONE = 0;

        int count = 0;
        int count2 = 0;

        


        public Tile[,] tiles;
        public Tile hero;

        public SKimGamePlaying()
        {
            InitializeComponent();
            BtnUP.Visible = false;
            BtnRIGHT.Visible = false;
            BtnLEFT.Visible = false;
            BtnDOWN.Visible = false;
        }

        

        public void loadFile(string filename)
        {
            StreamReader reader = new StreamReader(filename);
            int numberOfRows = int.Parse(reader.ReadLine());
            int numberOfCols = int.Parse(reader.ReadLine());
            tiles = new Tile[numberOfRows, numberOfCols];
            BtnDOWN.Visible = true;
            BtnLEFT.Visible = true;
            BtnRIGHT.Visible = true;
            BtnUP.Visible = true;

            for (int i = 0; i < numberOfRows; i++)
            {
                for (int j = 0; j < numberOfCols; j++)
                {
                    int row = int.Parse(reader.ReadLine());
                    int col = int.Parse(reader.ReadLine());
                    int tooltype = int.Parse(reader.ReadLine());

                    int EMPTY = 0;
                    if (tooltype != EMPTY)
                    {
                        Tile t = new Tile(row, col, tooltype);
                        
                        if (tooltype == HERO)
                        {
                            hero = t;
                            t.Image = SKimAssignment2.Properties.Resources.Hero;  // [i,j] = a.
                        }
                        else if (tooltype == WALL)
                        {
                            
                            t.Image = SKimAssignment2.Properties.Resources.Wall;
                            
                        }
                        else if (tooltype == BOX)
                        {
                            
                            t.Image = SKimAssignment2.Properties.Resources.YellowBox;

                        }
                        else if (tooltype == DOOR)
                        {
                            
                            t.Image = SKimAssignment2.Properties.Resources.YellowDoor;

                        }


                        tiles[i, j] = t;
                        this.Controls.Add(t);
                    }

                }
            }
        }

        private void LoadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = openFileDialog1.ShowDialog();
            switch (r)
            {
                case DialogResult.None:
                    break;
                case DialogResult.OK:
                    loadFile(openFileDialog1.FileName);
                    break;
                case DialogResult.Cancel:
                    break;
                case DialogResult.Abort:
                    break;
                case DialogResult.Retry:
                    break;
                case DialogResult.Ignore:
                    break;
                case DialogResult.Yes:
                    break;
                case DialogResult.No:
                    break;
                default:
                    break;
            }
        }

        public Tile getTile(int row, int col)
        {
            try
            {
                for (int i = 0; i < tiles.GetLength(0); i++)
                {
                    for (int j = 0; j < tiles.GetLength(1); j++)
                    {
                        if (tiles[i,j] != null)
                        {
                            if (tiles[i,j].row == row && tiles[i, j].col == col)
                            {
                                return tiles[i, j];
                            }
                        }
                        else
                        {
                            if (i == row && j == col)
                            {
                                return null;
                            }
                        }
                    }
                }
                return null;
            }
            catch (Exception)
            {
                
                return null;
            }
        }

        

        private void BtnRIGHT_Click(object sender, EventArgs e)
        {
            int currow = hero.row;
            int curcol = hero.col;
            int futurerow = currow;
            int futurecol = curcol + 1;

            count = int.Parse(txtnumbmove.Text);
            count++;
            txtnumbmove.Text = count.ToString();


            if (getTile(futurerow, futurecol) == null)
            {
                hero.col++;
            }
            else if (getTile(futurerow, futurecol).toolType == WALL)
            {
                // nothing for no move
            }
            else if (getTile(futurerow, futurecol).toolType == BOX)
            {

                hero.col++;
                count2 = int.Parse(txtnumbofpush.Text);
                count2++;
                txtnumbofpush.Text = count2.ToString();
                
                Tile box = getTile(futurerow, futurecol);
                box.col++;
                box.updateTile();

            }
            else if (getTile(futurerow, futurecol).toolType == DOOR)
            {
                hero.col++;
            }
            else
            {
                MessageBox.Show("ERROR - Moving");
            }

            hero.updateTile();
        }

        private void BtnUP_Click(object sender, EventArgs e)
        {
            int currow = hero.row;
            int curcol = hero.col;
            int futurerow = currow - 1;
            int futurecol = curcol;

            count = int.Parse(txtnumbmove.Text);
            count++;
            txtnumbmove.Text = count.ToString();
            if (getTile(futurerow, futurecol) == null)
            {
                hero.row--;
            }
            else if (getTile(futurerow, futurecol).toolType == WALL)
            {
                // nothing for no move
            }
            else if (getTile(futurerow, futurecol).toolType == BOX)
            {

                hero.row--;
                count2 = int.Parse(txtnumbofpush.Text);
                count2++;
                txtnumbofpush.Text = count2.ToString();

                Tile box = getTile(futurerow, futurecol);
                box.row--;
                box.updateTile();

            }
            else if (getTile(futurerow, futurecol).toolType == DOOR)
            {
                hero.row--;
            }
            else
            {
                MessageBox.Show("ERROR - Moving");
            }

            hero.updateTile();
        }

        private void BtnDOWN_Click(object sender, EventArgs e)
        {
            int currow = hero.row;
            int curcol = hero.col;
            int futurerow = currow + 1;
            int futurecol = curcol;

            count = int.Parse(txtnumbmove.Text);
            count++;
            txtnumbmove.Text = count.ToString();



            if (getTile(futurerow, futurecol) == null)
            {
                hero.row++;
            }
            else if (getTile(futurerow, futurecol).toolType == WALL)
            {
                // nothing for no move
            }
            else if (getTile(futurerow, futurecol).toolType == BOX)
            {

                hero.row++;
                count2 = int.Parse(txtnumbofpush.Text);
                count2++;
                txtnumbofpush.Text = count2.ToString();

                Tile box = getTile(futurerow, futurecol);
                box.row++;
                box.updateTile();

            }
            else if (getTile(futurerow, futurecol).toolType == DOOR)
            {
                hero.row++;
            }
            else
            {
                MessageBox.Show("ERROR - Moving");
            }

            hero.updateTile(); 
        }

        private void BtnLEFT_Click(object sender, EventArgs e)
        {
            int currow = hero.row;
            int curcol = hero.col;
            int futurerow = currow;
            int futurecol = curcol-1;

            count = int.Parse(txtnumbmove.Text);
            count++;
            txtnumbmove.Text = count.ToString();

            if (getTile(futurerow, futurecol) == null)
            {
                hero.col--;
            }
            else if (getTile(futurerow, futurecol).toolType == WALL)
            {
                // nothing for no move
            }
            else if (getTile(futurerow, futurecol).toolType == BOX)
            {

                hero.col--;
                count2 = int.Parse(txtnumbofpush.Text);
                count2++;
                txtnumbofpush.Text = count2.ToString();

                Tile box = getTile(futurerow, futurecol);
                box.col--;
                box.updateTile();

            }
            else if (getTile(futurerow, futurecol).toolType == DOOR)
            {
                hero.col--;
            }
            else
            {
                MessageBox.Show("ERROR - Moving");
            }

            hero.updateTile();
        }

    }
}
