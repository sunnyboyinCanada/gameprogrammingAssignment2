﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SKimAssignment2
{
    public partial class SKimGameControlPanel : Form
    {
        public SKimGameControlPanel()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnGameDesign_Click(object sender, EventArgs e)
        {
            SKimGameDesign G = new SKimGameDesign();
            G.Show();
        }

        private void BtnGamePlaying_Click(object sender, EventArgs e)
        {
            SKimGamePlaying P = new SKimGamePlaying();
            P.Show();
        }
    }
}
